Tiri door hub 0.29-revC - relink kit (GNU LGPL 2.1, section 6)

The hub firmware contains the Arduino-ESP32 core 3.3.12, which is licensed
under the GNU Lesser General Public License 2.1 (see licenses/LGPL-2.1.txt on
the update page). You may modify that library and relink it with the rest of
the firmware, for your own use, and reverse-engineer the firmware to debug
such changes. This kit lets you do that. It contains no source code of the
Tiri firmware: only its compiled object files (debug information removed).

Contents
  objects/sketch, objects/libraries   the rest of the firmware, compiled
  objects/core/core.a                 the unmodified Arduino-ESP32 core, as linked
  source/arduino-esp32-3.3.12    the core's source as used (LGPL-2.1, see LGPL-2.1.txt)
  source/fonts                        the GNU FreeFont glyph files used (GPL-3.0 + font exception)
  link.sh                             links them like the release, makes hub.bin

You need
  The esp32 core 3.3.12 by Espressif with its tools, installed by the
  Arduino IDE (Boards Manager -> esp32 -> 3.3.12) or arduino-cli.
  link.sh finds it in ~/Library/Arduino15 (macOS) or ~/.arduino15 (Linux);
  set ARDUINO15=<folder> otherwise.

Relink unchanged (to check your setup)
  ./link.sh          hub.bin then matches the release apart from its build hash

Relink with a modified core
  1. Change the core's source (packages/esp32/hardware/esp32/3.3.12/cores/esp32,
     or its Wire / SPI libraries).
  2. Build any sketch for "ESP32S3 Dev Module" with: USB Mode "Hardware CDC and
     JTAG", USB CDC On Boot "Enabled", Flash Size "16MB", Partition Scheme
     "16M Flash (3MB APP/9.9MB FATFS)", PSRAM "OPI PSRAM" (qio_opi), and take
     core/core.a from its build folder. A modified Wire or SPI library: compile
     it the same way and replace objects/libraries/Wire or SPI.
  3. CORE_A=/path/to/your/core.a ./link.sh
  4. Write hub.bin to the hub's app slot, without erasing anything else:
       esptool --chip esp32s3 write-flash 0x10000 hub.bin
     (0x9000-0xDFFF holds the hub's settings; don't write or erase it.)

Modified firmware is used at your own risk; the update page always installs
the official release again.
