#!/bin/sh
# Relinks Tiri door hub 0.29-revC (LGPL-2.1 section 6). See README.txt.
#   ./link.sh                              the release as published
#   CORE_A=/path/to/core.a ./link.sh       with your own build of the Arduino-ESP32 core
set -e
cd "$(dirname "$0")"
if [ -z "$ARDUINO15" ]; then
  if [ -d "$HOME/Library/Arduino15" ]; then ARDUINO15="$HOME/Library/Arduino15"; else ARDUINO15="$HOME/.arduino15"; fi
fi
T="$ARDUINO15/packages/esp32/tools"
LIBS="$T/esp32s3-libs/3.3.12"
GXX="$T/esp-x32/2601/bin/xtensa-esp32s3-elf-g++"
ESPTOOL="$T/esptool_py/5.3.1/esptool"
CORE_A="${CORE_A:-objects/core/core.a}"
for f in "$LIBS" "$GXX" "$ESPTOOL" "$CORE_A"; do
  [ -e "$f" ] || { echo "missing: $f (install the esp32 core 3.3.12, see README.txt)"; exit 1; }
done
"$GXX" -L"$LIBS/lib" -L"$LIBS/ld" -L"$LIBS/qio_opi" -Wl,--wrap=esp_panic_handler -Wl,--wrap=esp_bt_mem_release -Wl,--wrap=esp_bt_controller_mem_release -Wl,--wrap=_ZN4chip11DeviceLayer8Internal10ESP32Utils13InitWiFiStackEv -Wl,--wrap=_Z21esp_matter_mem_callocjj -Wl,--wrap=_Z22esp_matter_mem_reallocPvj -Wl,--wrap=_Z19esp_matter_mem_freePv \
  "@$LIBS/flags/ld_flags" "@$LIBS/flags/ld_scripts" \
  -Wl,--start-group \
  "objects/sketch/Tiri_doorhub.ino.cpp.o" \
  "objects/sketch/src/micro-ecc/uECC.c.o" \
  "objects/libraries/BLE/BLE2901.cpp.o" \
  "objects/libraries/BLE/BLE2902.cpp.o" \
  "objects/libraries/BLE/BLE2904.cpp.o" \
  "objects/libraries/BLE/BLEAddress.cpp.o" \
  "objects/libraries/BLE/BLEAdvertisedDevice.cpp.o" \
  "objects/libraries/BLE/BLEAdvertising.cpp.o" \
  "objects/libraries/BLE/BLEBeacon.cpp.o" \
  "objects/libraries/BLE/BLECharacteristic.cpp.o" \
  "objects/libraries/BLE/BLECharacteristicMap.cpp.o" \
  "objects/libraries/BLE/BLEClient.cpp.o" \
  "objects/libraries/BLE/BLEDescriptor.cpp.o" \
  "objects/libraries/BLE/BLEDescriptorMap.cpp.o" \
  "objects/libraries/BLE/BLEDevice.cpp.o" \
  "objects/libraries/BLE/BLEEddystoneTLM.cpp.o" \
  "objects/libraries/BLE/BLEEddystoneURL.cpp.o" \
  "objects/libraries/BLE/BLEExceptions.cpp.o" \
  "objects/libraries/BLE/BLEHIDDevice.cpp.o" \
  "objects/libraries/BLE/BLERemoteCharacteristic.cpp.o" \
  "objects/libraries/BLE/BLERemoteDescriptor.cpp.o" \
  "objects/libraries/BLE/BLERemoteService.cpp.o" \
  "objects/libraries/BLE/BLEScan.cpp.o" \
  "objects/libraries/BLE/BLESecurity.cpp.o" \
  "objects/libraries/BLE/BLEServer.cpp.o" \
  "objects/libraries/BLE/BLEService.cpp.o" \
  "objects/libraries/BLE/BLEServiceMap.cpp.o" \
  "objects/libraries/BLE/BLEUUID.cpp.o" \
  "objects/libraries/BLE/BLEUtils.cpp.o" \
  "objects/libraries/BLE/BLEValue.cpp.o" \
  "objects/libraries/BLE/FreeRTOS.cpp.o" \
  "objects/libraries/BLE/GeneralUtils.cpp.o" \
  "objects/libraries/SPI/SPI.cpp.o" \
  "objects/libraries/Adafruit_GFX_Library/Adafruit_GFX.cpp.o" \
  "objects/libraries/Adafruit_GFX_Library/Adafruit_GrayOLED.cpp.o" \
  "objects/libraries/Adafruit_GFX_Library/Adafruit_SPITFT.cpp.o" \
  "objects/libraries/Adafruit_GFX_Library/glcdfont.c.o" \
  "objects/libraries/Adafruit_BusIO/Adafruit_BusIO_Register.cpp.o" \
  "objects/libraries/Adafruit_BusIO/Adafruit_GenericDevice.cpp.o" \
  "objects/libraries/Adafruit_BusIO/Adafruit_I2CDevice.cpp.o" \
  "objects/libraries/Adafruit_BusIO/Adafruit_SPIDevice.cpp.o" \
  "objects/libraries/Wire/Wire.cpp.o" \
  "objects/libraries/Preferences/Preferences.cpp.o" \
  "objects/libraries/RTClib/RTC_DS1307.cpp.o" \
  "objects/libraries/RTClib/RTC_DS3231.cpp.o" \
  "objects/libraries/RTClib/RTC_Micros.cpp.o" \
  "objects/libraries/RTClib/RTC_Millis.cpp.o" \
  "objects/libraries/RTClib/RTC_PCF8523.cpp.o" \
  "objects/libraries/RTClib/RTC_PCF8563.cpp.o" \
  "objects/libraries/RTClib/RTClib.cpp.o" \
  "$CORE_A" "@$LIBS/flags/ld_libs" \
  -Wl,--end-group -Wl,-EL -o hub.elf
"$ESPTOOL" --chip esp32s3 elf2image --flash-mode dio --flash-freq 80m --flash-size 16MB \
  --elf-sha256-offset 0xb0 -o hub.bin hub.elf
echo "hub.bin written: write it at 0x10000 (README.txt)."
