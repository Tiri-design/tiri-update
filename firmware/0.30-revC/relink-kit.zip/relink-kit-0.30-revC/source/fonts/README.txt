Glyph data converted from GNU FreeFont (GPL-3.0-or-later with the font exception)
by the Adafruit GFX library's fontconvert tool. Original fonts:
https://savannah.gnu.org/projects/freefont/
